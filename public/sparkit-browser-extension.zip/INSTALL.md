# Sparkit Mimic 浏览器插件 - 安装指南

## 快速安装

### Chrome / Edge 安装步骤

1. **下载插件**
   ```bash
   cd /Users/a/sparkit/browser-extension
   ```

2. **创建图标**（临时使用占位图标）
   - 图标文件已经在 `icons/` 目录下准备好
   - 如果需要自定义，替换 icon-16.png, icon-32.png, icon-48.png, icon-128.png

3. **打开 Chrome 扩展程序页面**
   - 在地址栏输入: `chrome://extensions/`
   - 或菜单: 更多工具 > 扩展程序

4. **启用开发者模式**
   - 打开右上角的"开发者模式"开关

5. **加载插件**
   - 点击"加载已解压的扩展程序"
   - 选择 `/Users/a/sparkit/browser-extension` 文件夹
   - 点击"选择"

6. **验证安装**
   - 插件图标应该出现在浏览器工具栏
   - 点击图标查看弹窗

### Firefox 安装步骤

1. **打开调试页面**
   - 地址栏输入: `about:debugging#/runtime/this-firefox`

2. **临时加载**
   - 点击"临时加载附加组件"
   - 选择 `/Users/a/sparkit/browser-extension/manifest.json`

3. **验证安装**
   - 插件图标应该出现在工具栏

## 配置

### 1. 修改 API 地址

如果你的 Sparkit 部署在自定义域名，需要修改以下文件：

**文件 1: `background/background.js`**
```javascript
// 第 4 行
const SPARKIT_API_URL = 'https://你的域名.com';
```

**文件 2: `popup/popup.js`**
```javascript
// 第 3 行
const SPARKIT_API_URL = 'https://你的域名.com';
```

### 2. 登录 Sparkit

1. 点击插件图标
2. 点击"打开 Sparkit 网站"
3. 在网站上登录你的账号
4. 回到插件，状态应显示"已登录"

### 3. 创建角色

1. 在 Sparkit 网站进入"角色管理"
2. 创建至少一个角色
3. 上传角色图片（char_image 必需，char_avatar 可选）

## 使用教程

### 基础使用

1. **浏览图片**
   - 打开 Pinterest、Instagram 或其他网站
   - 浏览包含人物的图片

2. **启动 Mimic**
   - 鼠标悬停在图片上
   - 右下角会出现紫色的"Mimic"按钮
   - 点击按钮

3. **配置生成**
   - 在弹出的模态框中选择角色
   - 选择是否保留背景
   - 点击"生成 (2张)"按钮

4. **等待结果**
   - 插件会显示生成进度
   - 约 30-60 秒后完成
   - 结果会显示在右侧预览区

5. **下载保存**
   - 点击图片上的下载按钮保存
   - 或在 Sparkit 网站的角色资源中查看

### 角色记忆功能

- 插件会自动记住你上次选择的角色
- 下次使用时会默认选中该角色
- 可以随时点击"切换角色"更换

### 背景保留选项

**勾选"保留参考图背景"**:
- 插件会去除参考图中的人物
- 保留原始场景和环境
- 将你的角色放入该场景

**不勾选"保留参考图背景"**:
- 只使用参考图的场景描述
- AI 自由生成背景环境
- 效果更有创意但可能与原图差异较大

## 故障排除

### 插件无法加载

**症状**: Chrome 提示"无法加载扩展程序"

**解决方案**:
1. 检查 manifest.json 是否正确
2. 确认所有文件都存在
3. 检查文件权限

### 连接失败

**症状**: 弹窗显示"未连接"

**解决方案**:
1. 检查 SPARKIT_API_URL 配置是否正确
2. 确认 Sparkit 网站正常运行
3. 检查网络连接
4. 查看浏览器控制台错误

### 未登录

**症状**: 弹窗显示"未登录"

**解决方案**:
1. 打开 Sparkit 网站并登录
2. 重新加载扩展程序
3. 检查 Cookie 是否被阻止

### Mimic 按钮不显示

**症状**: 悬停图片时没有按钮

**解决方案**:
1. 确认图片尺寸 > 100x100px
2. 刷新页面
3. 检查控制台是否有错误
4. 确认网站在支持列表中

### 生成失败

**症状**: 点击生成后提示错误

**常见错误**:

1. **"未选择角色"**
   - 在列表中选择一个角色

2. **"获取角色信息失败"**
   - 检查网络连接
   - 确认角色仍然存在

3. **"内容被安全过滤阻止"**
   - 参考图内容可能违反 AI 政策
   - 尝试其他图片

4. **"生成失败，请重试"**
   - 检查 Gemini API 配额
   - 稍后重试

## 查看日志

### Chrome DevTools

1. **Content Script 日志**:
   - 打开网页控制台 (F12)
   - 筛选 `[Sparkit Mimic]`

2. **Background Worker 日志**:
   - chrome://extensions/
   - 点击"Service Worker"下的"检查视图"
   - 查看控制台

3. **Popup 日志**:
   - 右键点击插件图标
   - 选择"检查弹出内容"

## 卸载

### Chrome
1. 进入 `chrome://extensions/`
2. 找到 Sparkit Mimic
3. 点击"移除"

### Firefox
1. 进入 `about:addons`
2. 找到 Sparkit Mimic
3. 点击"移除"

## 更新插件

1. 拉取最新代码
   ```bash
   cd /Users/a/sparkit
   git pull
   ```

2. Chrome: 在扩展程序页面点击"重新加载"图标
3. Firefox: 需要重新临时加载

## 开发调试

### 本地开发模式

1. 启动 Sparkit 开发服务器
   ```bash
   cd /Users/a/sparkit
   npm run dev
   ```

2. 修改插件配置使用本地 API
   ```javascript
   const SPARKIT_API_URL = 'http://localhost:3000';
   ```

3. 重新加载扩展程序

### 测试流程

1. 打开测试网站（如 Pinterest）
2. 打开浏览器控制台监控日志
3. 悬停图片测试按钮显示
4. 点击按钮测试模态框
5. 测试角色选择
6. 测试生成流程
7. 检查结果保存

## 常见配置

### 增加支持的网站

编辑 `manifest.json`:

```json
{
  "content_scripts": [
    {
      "matches": [
        "https://新网站.com/*"
      ]
    }
  ]
}
```

### 修改生成数量

编辑 `content/content-script.js`:

```javascript
// 找到 handleGenerate 函数
formData.append('numImages', '4'); // 改为 4 张
```

### 自定义按钮样式

编辑 `content/content-script.css`:

```css
.sparkit-mimic-btn {
  background: linear-gradient(135deg, #你的颜色 0%, #你的颜色 100%);
}
```

## 技术支持

- 问题反馈: GitHub Issues
- 功能建议: GitHub Discussions
- 官方网站: https://sparkiai.com

---

🎉 安装完成！开始使用 Sparkit Mimic 创作吧！

